"""Services package initialization"""
from .EmailService import EmailService

__all__ = ['EmailService']
